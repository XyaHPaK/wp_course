<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', '' );

/** Имя пользователя MySQL */
define( 'DB_USER', '' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', '' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '#JSQH39OGWWx{-[D{AHBw {|$;]o%^BZH<M:3SAtao?H|`)UaT7-CS3sBvR8{}cY' );
define( 'SECURE_AUTH_KEY',  'Zy(`)indLrw0U[cHjvg&dYav|E;Xh%~.}5HiSd7}(q<>SX.VN9OCDGs[OQQgbi_6' );
define( 'LOGGED_IN_KEY',    'hoGV_o84:/xSFa*Qo/}:V.hdeN0DX>$WD~]mat~F e;%qxRG8F$q#776;,lg%I)H' );
define( 'NONCE_KEY',        'Ldd,z8t=4w-iVN[K|/C+fvpay(;Bbt#zy/VM6T*^=hoZ{M&]=qezXb5!ZkV![:C+' );
define( 'AUTH_SALT',        't8:X~d?7=+_./s;Y]3u ( .1dW/LWkN[/0[WcdK 3=7nJ60;B7m[BRmI0kvNw!*f' );
define( 'SECURE_AUTH_SALT', '$F5[3N4aE3?U(LUoNaOz8xiBE-6Q[&EL[(:.%|O?$$Sf.[;eF39{<pSimhQ>oNCq' );
define( 'LOGGED_IN_SALT',   'S>eyy(o3>ajXmjnj]77Kx;9Y~[>hEnjiDOKDjGJuu`+g#b,0Y6G&|*y!#evIZK} ' );
define( 'NONCE_SALT',       '|[]bch`+0#f4(@-G)tP<3(:F2Q,+H6@(JtK[H L(|f_NvPeeUj[D8>CftWZ*&KTi' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', true );

// ** Optimization ** //
/** Posts revisions */
define('AUTOSAVE_INTERVAL', 300);
define('WP_POST_REVISIONS', 5);

/** Trash cleaning interval */
define('EMPTY_TRASH_DAYS', 30);

/** auto db optimization */
define('WP_ALLOW_REPAIR', true);

// Disable Editing files in admin panel
define( 'DISALLOW_FILE_EDIT', true );

// SSL usage
define( 'FORCE_SSL_ADMIN', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
