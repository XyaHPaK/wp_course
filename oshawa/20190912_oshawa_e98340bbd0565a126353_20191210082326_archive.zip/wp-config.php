<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', '');
/** MySQL database username */
define('DB_USER', '');
/** MySQL database password */
define('DB_PASSWORD', '');
/** MySQL hostname */
define('DB_HOST', '');
/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');
/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'AGsyJkY)P*HSZGhAy4rDr7^h2l)DNyNF)3MUcfzbQhIJ)mJTRwSc*RU%EwE@3%%3');
define('SECURE_AUTH_KEY',  'GHn!a^pi8gRFvS1i!VQT3GP#56Nz4qj#ee1iA46#PNLnd3MG1G9%g!%Mr)jEokUH');
define('LOGGED_IN_KEY',    'fhHZ&^7paO0bdzIN))JDRO^k(XBAL*HGqa4A9L33yOUe3x*uba8@Wx&&@eRF^SGl');
define('NONCE_KEY',        'XAFh)wT6JlRpDs&iHZsZv2DC45^V2vO1Yps9Vmr!k5KTX6Q9(dIMJGb7kgOwCDym');
define('AUTH_SALT',        '^sjdfZW8q5huJh0#3Y!RwDi8g*XRuH%7BqhytnA5&5GnY5EmyNNxOE3*j^kt11pc');
define('SECURE_AUTH_SALT', 'X(#bw@WqKq9XyBMA0jZ1v3x6mbGEjm12YLZ%Hfo^dwk8mG#JB0@oysZ0sU40^XUX');
define('LOGGED_IN_SALT',   ')O@qD7GLRHXyM#8tdsW4n2J7LaJe49EcvK)&1))XiWgn#uHc1ysi*(wNg!3McrJE');
define('NONCE_SALT',       'qkBumhd8tETu*VLkGh0xD(%W%BIFk2h41zK2E)gXw2DYfP4)&6qtE3UpDwXFf5Zd');
/**#@-*/
/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );
//define( 'WP_DEBUG_LOG', true );
//define( 'WP_DEBUG_DISPLAY', false );
//define( 'SCRIPT_DEBUG', true );
/* That's all, stop editing! Happy blogging. */
/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define( 'WP_ALLOW_MULTISITE', true );
define ('FS_METHOD', 'direct');